Our Final Predictions are as Follows
Winner is Brazil
Runner up is Argentina
Semi-Finalists are Argentina, England, Japan, Brazil�

Our predictions are based on following:
1) Only World Cup data is picked for prediction from URL https://github.com/jokecamp/FootballData
2) Data before world wars were not included into the prediction.
4) Prediction is totally based on probablity of a team winning against other team
5) Only to 16 teams were included for analysis
